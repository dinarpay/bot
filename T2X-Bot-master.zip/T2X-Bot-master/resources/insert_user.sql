INSERT INTO users (user_id, address, privkey)
VALUES (?, ?, ?)