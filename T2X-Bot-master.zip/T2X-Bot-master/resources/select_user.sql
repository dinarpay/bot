SELECT *
FROM users
WHERE user_id = ?