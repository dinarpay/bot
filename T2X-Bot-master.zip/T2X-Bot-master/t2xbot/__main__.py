from t2xbot.start import T2XBot

# Entry point for bot
T2XBot().start()
