import logging
import t2xbot.emoji as emo
import t2xbot.constants as con

from typing import Union
from tronapi import Tron
from decimal import Decimal
from telegram import ParseMode


class T2X:

    # Smart contract address
    T2X_SC = "THsSSczBw9RRMJWYL5j2MtcgaPasL2xPGP"

    def send(self, wallet: Tron, to_address: str, amount: float):
        cont_kwargs = dict()
        cont_kwargs["contract_address"] = wallet.address.to_hex(self.T2X_SC)
        cont_kwargs["function_selector"] = "transfer(address,uint256)"
        cont_kwargs["fee_limit"] = wallet.toSun(con.TRX_FEE_LIMIT)
        cont_kwargs["call_value"] = 0
        cont_kwargs["parameters"] = [
            {
                'type': 'address',
                'value': to_address
            },
            {
                'type': 'uint256',
                'value': self.to_atom(amount)
            }
        ]

        logging.info(f"Executing smart contract: {cont_kwargs}")

        try:
            # Create raw transaction
            raw_tx = wallet.transaction_builder.trigger_smart_contract(**cont_kwargs)
            # Sign the raw transaction
            sig_tx = wallet.trx.sign(raw_tx["transaction"])
            # Broadcast the signed transaction
            result = wallet.trx.broadcast(sig_tx)

            return result
        except Exception as e:
            return {"error": e}

    @staticmethod
    def to_atom(amount: Union[Decimal, int, float]) -> int:
        return int(amount * 100000000)

    @staticmethod
    def from_atom(amount: int) -> float:
        return float(amount / 100000000)

    @staticmethod
    def check_tx_job(bot, job):
        message = job.context["message"]
        tx_hash = job.context["tx_hash"]
        text = job.context["text"]

        try:
            tx = Tron().trx.get_transaction_info(tx_hash)

            if tx:
                logging.info(f"Job {tx_hash} - {tx}")

                if tx["receipt"]["result"] == "SUCCESS":
                    msg = text.replace(emo.WAIT, emo.DONE)
                else:
                    msg = text.replace(emo.WAIT, emo.FAIL)

                message.edit_text(
                    msg,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True)

                job.schedule_removal()
                logging.info(f"Job {tx_hash} - Ended")
        except Exception as e:
            job.schedule_removal()
            logging.error(f"Job {tx_hash} ERROR: {e}")
