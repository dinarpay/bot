from telegram import ParseMode
from t2xbot.plugin import T2XBotPlugin


class About(T2XBotPlugin):

    INFO_FILE = "info.md"

    @T2XBotPlugin.private
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        update.message.reply_text(
            text=self.get_resource(self.INFO_FILE),
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
            quote=False)
