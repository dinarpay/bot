✨ *T2X - Next Generation Staking* ✨  

This bot was written in Python by @endogen for the T2X community. If you are interested in the source code then check out the [GitHub repository](https://github.com/Endogen/T2X-Bot).  

If you want to support me then send T2X to this wallet:  
`TMMeFzXfVDPoGbSpSyXRNfTnhUZS7m8aRs`

Or use my referral link (you will get 5% more tokens):  
`https://t2xtoken.io/?ref=TMMeFzXfVDPoGbSpSyXRNfTnhUZS7m8aRs`