import logging
import t2xbot.emoji as emo
import t2xbot.constants as con

from tronapi import Tron
from t2xbot.t2x import T2X
from telegram import ParseMode
from trx_utils import is_address
from t2xbot.plugin import T2XBotPlugin
from t2xbot.trongrid import Trongrid
from t2xbot.tronscan import Tronscan


class Withdrawt2x(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("withdrawals"):
            sql = self.get_resource("create_withdrawals.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.private
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 1:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        to_address = args[0]

        # Check if provided address is valid
        if not bool(is_address(to_address)):
            msg = f"{emo.ERROR} Provided {con.T2X_TICKER} wallet is not valid"
            update.message.reply_text(msg)
            return

        user_id = update.effective_user.id

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, user_id)

        if not res["success"] or not res["data"]:
            msg = f"{emo.ERROR} Something went wrong. Please contact @endogen"

            logging.error(f"{msg}: {res} - {update}")
            update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)
            return

        from_address = res["data"][0][1]

        tron_kwargs = dict()
        tron_kwargs["private_key"] = res["data"][0][2]
        tron_kwargs["default_address"] = from_address

        tron = Tron(**tron_kwargs)

        # Check if enough TRX to pay for smart contract execution
        if tron.trx.get_balance() == 0:
            msg = f"{emo.ERROR} Not enough TRX to withdraw {con.T2X_TICKER}"
            logging.info(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        account = Trongrid().get_account(from_address)

        balance_atom = 0
        balance_show = 0

        # Get T2X balance
        if account and account["data"]:
            for trc20 in account["data"][0]["trc20"]:
                for trc20_addr, trc20_bal in trc20.items():
                    if trc20_addr == T2X.T2X_SC:
                        balance_atom = int(trc20_bal)
                        balance_show = T2X.from_atom(balance_atom)

        try:
            send = T2X().send(tron, to_address, balance_show)
            logging.info(f"Withdrawn {balance_show} {con.T2X_TICKER} from {from_address} to {to_address}: {send}")

            if "transaction" not in send:
                logging.error(f"Key 'transaction' not in result")
                raise Exception(send["message"])

            txid = send["transaction"]["txID"]

            sql = self.get_resource("insert_withdrawal.sql")
            self.execute_sql(sql, from_address, to_address, balance_atom, txid)

            if balance_show.is_integer():
                balance_show = int(balance_show)

            msg = f"{emo.WAIT} Withdrawn `{balance_show}` {con.T2X_TICKER}\n"\
                  f"[View on Explorer]({Tronscan.TX_URL}{txid})"

            message = update.message.reply_text(
                msg,
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True)

            context = {
                "message": message,
                "tx_hash": txid,
                "text": msg
            }

            self.repeat_job(T2X.check_tx_job, 5, first=60, context=context)
            self.remove_msg(message, also_private=False)
        except Exception as e:
            msg = f"{emo.ERROR} Could not withdraw {con.T2X_TICKER}: {e}"

            logging.error(msg)
            update.message.reply_text(msg)
