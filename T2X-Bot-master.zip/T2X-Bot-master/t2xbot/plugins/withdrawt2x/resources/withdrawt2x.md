
`/{{handle}} <address>`
Use this command to withdraw the *whole amount* of T2X in your wallet and sent it over to another wallet