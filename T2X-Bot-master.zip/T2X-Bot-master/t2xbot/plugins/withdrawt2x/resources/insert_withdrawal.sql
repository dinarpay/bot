INSERT INTO withdrawals (from_address, to_address, amount, txid)
VALUES (?, ?, ?, ?)