
`/{{handle}} <your feedback>`  
Send feedback to the bot creator