INSERT INTO feedback (user_id, first_name, username, feedback)
VALUES (?, ?, ?, ?)