
`/{{handle}} <amount> <address>`
Use this command to send T2X from your bot wallet to some other wallet