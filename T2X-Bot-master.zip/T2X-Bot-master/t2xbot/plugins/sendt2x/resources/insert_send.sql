INSERT INTO send (from_address, to_address, amount, txid)
VALUES (?, ?, ?, ?)