import logging
import t2xbot.emoji as emo
import t2xbot.constants as con

from tronapi import Tron
from t2xbot.t2x import T2X
from telegram import ParseMode
from trx_utils import is_address
from t2xbot.trongrid import Trongrid
from t2xbot.tronscan import Tronscan
from t2xbot.plugin import T2XBotPlugin


class Sendt2x(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("send"):
            sql = self.get_resource("create_send.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 2:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        amount = args[0]

        # Check if amount is valid
        try:
            amount = float(amount)
        except:
            msg = f"{emo.ERROR} Provided amount is not valid"
            logging.info(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        to_address = args[1]

        # Check if provided address is valid
        if not bool(is_address(to_address)):
            msg = f"{emo.ERROR} Provided wallet is not valid"
            logging.info(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        user_id = update.effective_user.id

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, user_id)

        if not res["success"] or not res["data"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        from_address = res["data"][0][1]

        grid = Trongrid().get_account(from_address)

        balance = 0

        # Get T2X balance
        if grid and grid["data"]:
            for trc20 in grid["data"][0]["trc20"]:
                for trc20_addr, trc20_bal in trc20.items():
                    if trc20_addr == T2X().T2X_SC:
                        balance = T2X.from_atom(int(trc20_bal))
                        break

        # Check if address has enough balance
        if amount > balance:
            msg = f"{emo.ERROR} {con.T2X_TICKER} balance not sufficient"
            logging.info(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        tron_kwargs = dict()
        tron_kwargs["private_key"] = res["data"][0][2]
        tron_kwargs["default_address"] = from_address

        tron = Tron(**tron_kwargs)

        try:
            send = T2X().send(tron, to_address, amount)
            logging.info(f"Sending {amount} {con.T2X_TICKER} from {from_address} to {to_address}: {send}")

            if "transaction" not in send:
                logging.error(f"Key 'transaction' not in result: {send}")
                raise Exception(send["message"])

            txid = send["transaction"]["txID"]

            # Insert transaction into database
            sql = self.get_resource("insert_send.sql")
            self.execute_sql(sql, from_address, to_address, T2X.to_atom(amount), txid)

            if amount.is_integer():
                amount = int(amount)

            msg = f"{emo.WAIT} Sent `{amount}` {con.T2X_TICKER}\n"\
                  f"[View on Explorer]({Tronscan.TX_URL}{txid})"

            message = update.message.reply_text(
                msg,
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True)

            context = {
                "message": message,
                "tx_hash": txid,
                "text": msg
            }

            self.repeat_job(T2X.check_tx_job, 5, first=60, context=context)
            self.remove_msg(message, also_private=False)
        except Exception as e:
            msg = f"{emo.ERROR} Could not send {con.T2X_TICKER}: {e}"

            logging.error(msg)
            update.message.reply_text(msg)
