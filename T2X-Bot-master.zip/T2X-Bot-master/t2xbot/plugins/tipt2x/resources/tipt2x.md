
You can tip a user with T2X tokens by replying to one of his messages and specifying the amount of T2X to tip.  

`/{{handle}} <amount>`  
Tip a user with T2X tokens