import logging
import t2xbot.emoji as emo
import t2xbot.utils as utl
import t2xbot.constants as con

from tronapi import Tron
from t2xbot.t2x import T2X
from telegram import ParseMode
from t2xbot.trongrid import Trongrid
from t2xbot.tronscan import Tronscan
from t2xbot.plugin import T2XBotPlugin


class Tipt2x(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("tips"):
            sql = self.get_resource("create_tips.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 1:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        reply = update.message.reply_to_message

        if not reply:
            msg = f"{emo.ERROR} You can only tip by replying to a message"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        amount = args[0]
        to_user_id = reply.from_user.id

        try:
            # Check if amount is valid
            amount = float(amount)
        except:
            msg = f"{emo.ERROR} Provided amount is not valid"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, to_user_id)

        if not res["success"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        if res["data"]:
            to_address = res["data"][0][1]
        else:
            to_address, _ = self.add_user_wallet(reply.from_user.id, return_data=True)

        from_user_id = update.effective_user.id

        if update.effective_user.username:
            from_user = f"@{update.effective_user.username}"
        else:
            from_user = update.effective_user.first_name

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, from_user_id)

        if not res["success"] or not res["data"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        data = res["data"]

        trx_kwargs = dict()
        trx_kwargs["private_key"] = data[0][2]
        trx_kwargs["default_address"] = data[0][1]

        tron = Tron(**trx_kwargs)

        # Check if address has enough TRX to pay for smart contract execution
        if tron.trx.get_balance() == 0:
            msg = f"{emo.ERROR} TRX balance not sufficient"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        grid = Trongrid().get_account(data[0][1])

        balance = 0

        # Get T2X balance
        if grid and grid["data"]:
            for trc20 in grid["data"][0]["trc20"]:
                for trc20_addr, trc20_bal in trc20.items():
                    if trc20_addr == T2X().T2X_SC:
                        balance = T2X.from_atom(int(trc20_bal))
                        break

        # Check if address has enough balance
        if amount > balance:
            msg = f"{emo.ERROR} {con.T2X_TICKER} balance not sufficient"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        try:
            tip = T2X().send(tron, to_address, amount)
            logging.info(f"Tipped {amount} {con.T2X_TICKER} from {from_user_id} to {to_user_id}: {tip}")

            if "transaction" not in tip:
                logging.error(f"Key 'transaction' not in result: {tip}")
                raise Exception(tip["message"])

            txid = tip["transaction"]["txID"]

            # Insert details into database
            sql = self.get_resource("insert_tip.sql")
            self.execute_sql(sql, from_user_id, to_user_id, T2X.to_atom(amount), txid)

            if amount.is_integer():
                amount = int(amount)

            if reply.from_user.username:
                to_user = f"@{reply.from_user.username}"
            else:
                to_user = reply.from_user.first_name

            msg = f"{emo.WAIT} {utl.esc_md(to_user)} received `{amount}` {con.T2X_TICKER}\n"\
                  f"[View on Explorer]({Tronscan.TX_URL}{txid})"

            message = update.message.reply_text(
                msg,
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True)

            # Notify user about tip
            try:
                bot.send_message(
                    to_user_id,
                    f"You received `{amount}` {con.T2X_TICKER} from {utl.esc_md(from_user)}\n"
                    f"[View on Explorer]({Tronscan.TX_URL}{txid})",
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True)
                logging.info(f"User {to_user_id} notified about tip of {amount} {con.T2X_TICKER}")
            except Exception as e:
                logging.info(f"User {to_user_id} could not be notified about tip: {e}")

            context = {
                "message": message,
                "tx_hash": txid,
                "text": msg
            }

            self.repeat_job(T2X.check_tx_job, 5, first=60, context=context)
        except Exception as e:
            msg = f"{emo.ERROR} Could not tip {con.T2X_TICKER}: {e} - {update}"

            logging.error(msg)
            update.message.reply_text(msg)
