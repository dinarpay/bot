from collections import OrderedDict
from t2xbot.plugin import T2XBotPlugin


class Help(T2XBotPlugin):

    @T2XBotPlugin.private
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        categories = OrderedDict()

        for p in self.get_plugins():
            if p.get_category() and p.get_description():
                des = f"/{p.get_handle()} - {p.get_description()}"

                if p.get_category() not in categories:
                    categories[p.get_category()] = [des]
                else:
                    categories[p.get_category()].append(des)

        msg = "AVAILABLE COMMANDS\n\n"

        for category in sorted(categories):
            msg += f"{category}\n"

            for cmd in sorted(categories[category]):
                msg += f"{cmd}\n"

            msg += "\n"

        message = update.message.reply_text(
            text=msg,
            disable_web_page_preview=True)

        self.remove_msg(message, also_private=False)
