from tronapi import Tron
from t2xbot.t2x import T2X
from telegram import ParseMode
from t2xbot.plugin import T2XBotPlugin
from t2xbot.trongrid import Trongrid


class Balance(T2XBotPlugin):

    TRON_SCAN_URL = "https://tronscan.org/#/address/"

    @T2XBotPlugin.private
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        user_id = update.effective_user.id

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, user_id)

        trx_kwargs = dict()
        trx_kwargs["private_key"] = res["data"][0][2]
        trx_kwargs["default_address"] = res["data"][0][1]

        tron = Tron(**trx_kwargs)

        trx_balance = tron.fromSun(tron.trx.get_balance())

        account = Trongrid().get_account(res["data"][0][1])

        t2x_balance = 0

        if account and account["data"]:
            for trc20 in account["data"][0]["trc20"]:
                for trc20_addr, trc20_bal in trc20.items():
                    if trc20_addr == T2X.T2X_SC:
                        t2x_balance = T2X.from_atom(int(trc20_bal))
                        if t2x_balance.is_integer():
                            t2x_balance = int(t2x_balance)
                        break

        msg = f"*Balance*\n\n" \
              f"`TRX: {trx_balance}`\n" \
              f"`T2X: {t2x_balance}`\n\n" \
              f"[View on Tronscan]({self.TRON_SCAN_URL}{res['data'][0][1]})"

        message = update.message.reply_text(
            msg,
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True)

        self.remove_msg(message, also_private=False)
