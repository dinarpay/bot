
`/{{handle}}`  
Backup the whole bot

`/{{handle}} <plugin name>`  
Backup a specific plugin