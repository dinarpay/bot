
`/{{handle}} <amount> <address>`
Use this command to send TRX from your bot wallet to some other wallet