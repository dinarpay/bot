
You can tip a user with TRX tokens by replying to one of his messages and specifying the amount of TRX to tip.

`/{{handle}} <username> <amount>`  
Tip a user with TRX coins