import logging
import t2xbot.emoji as emo
import t2xbot.utils as utl

from tronapi import Tron
from telegram import ParseMode
from t2xbot.tronscan import Tronscan
from t2xbot.plugin import T2XBotPlugin


class Tiptrx(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("tips"):
            sql = self.get_resource("create_tips.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 1:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        reply = update.message.reply_to_message

        if not reply:
            msg = f"{emo.ERROR} You can only tip by replying to a message"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        amount = args[0]
        to_user_id = reply.from_user.id

        try:
            # Check if amount is valid
            amount = float(amount)
        except:
            msg = f"{emo.ERROR} Provided amount is not valid"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, to_user_id)

        if not res["success"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        if res["data"]:
            to_address = res["data"][0][1]
        else:
            to_address, _ = self.add_user_wallet(reply.from_user.id, return_data=True)

        from_user_id = update.effective_user.id

        if update.effective_user.username:
            from_user = f"@{update.effective_user.username}"
        else:
            from_user = update.effective_user.first_name

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, from_user_id)

        if not res["success"] or not res["data"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        data = res["data"]

        trx_kwargs = dict()
        trx_kwargs["private_key"] = data[0][2]
        trx_kwargs["default_address"] = data[0][1]

        tron = Tron(**trx_kwargs)

        balance_atom = tron.trx.get_balance()
        balance_show = tron.fromSun(balance_atom)

        # Check if address has enough balance
        if amount > float(balance_show):
            msg = f"{emo.ERROR} TRX balance not sufficient"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        try:
            tip = tron.trx.send(to_address, amount)
            logging.info(f"Tipped {amount} TRX from {from_user_id} to {to_user_id}: {tip}")

            if "transaction" not in tip:
                logging.error(tip)
                raise Exception("key 'transaction' not in send result")

            txid = tip["transaction"]["txID"]

            # Insert details into database
            sql = self.get_resource("insert_tip.sql")
            self.execute_sql(sql, from_user_id, to_user_id, tron.toSun(amount), txid)

            if amount.is_integer():
                amount = int(amount)

            if reply.from_user.username:
                to_user = f"@{reply.from_user.username}"
            else:
                to_user = reply.from_user.first_name

            update.message.reply_text(
                f"{emo.DONE} {utl.esc_md(to_user)} received `{amount}` TRX\n"
                f"[View on Explorer]({Tronscan.TX_URL}{txid})",
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True)

            # Notify user about tip
            try:
                bot.send_message(
                    to_user_id,
                    f"You received `{amount}` TRX from {utl.esc_md(from_user)}\n"
                    f"[View on Explorer]({Tronscan.TX_URL}{txid})",
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True)
                logging.info(f"User {to_user_id} notified about tip of {amount} TRX")
            except Exception as e:
                logging.info(f"User {to_user_id} could not be notified about tip: {e}")
        except Exception as e:
            msg = f"{emo.ERROR} Could not tip TRX: {e} - {update}"

            logging.error(msg)
            update.message.reply_text(msg)
