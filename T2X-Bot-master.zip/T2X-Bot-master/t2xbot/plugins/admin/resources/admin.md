
`/{{handle}} sql <plugin name> <database name> <sql statement>`  
Execute SQL statements on any database of a plugin

`/{{handle}} cfg <plugin name> <config name> get|set <key> (<sub key> ...) (<value>)`  
Get or set a value in the global configuration file or in a plugin configuration file

`/{{handle}} plg <plugin name> add`  
Enable a specific plugin

`/{{handle}} plg <plugin name> remove`  
Disable a specific plugin