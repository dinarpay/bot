
Rain T2X tokens on random users in the group  

`/{{handle}} <T2X amount> <nr. of users>`  
Tip users with T2X tokens