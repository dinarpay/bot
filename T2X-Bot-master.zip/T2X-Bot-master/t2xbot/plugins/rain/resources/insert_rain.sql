INSERT INTO rain (from_user_id, to_user_id, amount, txid)
VALUES (?, ?, ?, ?)