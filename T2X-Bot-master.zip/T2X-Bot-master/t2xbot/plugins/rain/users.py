#!/usr/bin/python3

import os
import csv

from telethon import TelegramClient
from telethon.tl.types import UserStatusRecently

api_id = 459667
api_hash = 'ed7ee8b5be1eb6ba67dbd35a71bf848a'

# TODO: Use self.get_plg_path() for the rain plugin
PATH = os.path.join("t2xbot", "plugins", "rain", "resources", "users.csv")

client = TelegramClient('anon', api_id, api_hash)


# TODO: Improve it so that script can be also run on it's own
async def main():
    await client.get_dialogs()
    with open(PATH, "w", encoding='UTF-8') as f:
        writer = csv.writer(f, delimiter=",", lineterminator="\n")

        index = 1
        for user in await client.get_participants(1191546954):
            if index > 200:
                break
            else:
                index += 1
            if user.bot:
                continue
            if not isinstance(user.status, UserStatusRecently):
                continue

            username = "@" + user.username if user.username else user.first_name
            writer.writerow([username, user.id, user.access_hash, user.status])

with client:
    client.loop.run_until_complete(main())
