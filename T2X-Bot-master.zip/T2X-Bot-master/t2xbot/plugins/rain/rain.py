import os
import csv
import time
import logging
import t2xbot.emoji as emo
import t2xbot.constants as con

from tronapi import Tron
from t2xbot.t2x import T2X
from telegram import ParseMode
from t2xbot.trongrid import Trongrid
from t2xbot.plugin import T2XBotPlugin


class Rain(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("rain"):
            sql = self.get_resource("create_rain.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.public
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 2:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        # Total amount of T2X to rain
        amount_total = args[0]
        # Number of users to rain on
        nr_of_users = args[1]

        try:
            # Check if amount is valid
            amount_total = float(amount_total)
        except:
            msg = f"{emo.ERROR} Provided T2X amount is not valid"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        try:
            # Check if number of users is valid
            nr_of_users = float(nr_of_users)
        except:
            msg = f"{emo.ERROR} Provided number of users is not valid"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        # Amount of T2X to rain to one user
        amount_single = float(f"{(amount_total / nr_of_users):.2f}")
        from_user_id = update.message.from_user.id

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, from_user_id)

        if not res["success"]:
            msg = f"{emo.ERROR} Something went wrong. Developers got notified"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            self.notify(f"{msg} - {res}")
            return

        trx_kwargs = dict()
        trx_kwargs["private_key"] = res["data"][0][2]
        trx_kwargs["default_address"] = res["data"][0][1]

        tron = Tron(**trx_kwargs)

        grid = Trongrid().get_account(res["data"][0][1])

        balance_atom = 0
        balance_show = 0

        # Get T2X balance
        if grid and grid["data"]:
            for trc20 in grid["data"][0]["trc20"]:
                for trc20_addr, trc20_bal in trc20.items():
                    if trc20_addr == T2X().T2X_SC:
                        balance_atom = int(trc20_bal)
                        balance_show = T2X.from_atom(balance_atom)
                        break

        # Check if address has enough T2X balance
        if amount_total > float(balance_show):
            msg = f"{emo.ERROR} {con.T2X_TICKER} balance not sufficient"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)
            return

        msg = f"{emo.RAIN} Invoking rain clouds..."
        message = update.message.reply_text(msg)

        # Generate CSV file with all recently seen users
        # TODO: Use `self.get_plg_path()`
        os.system(f"python3 ./t2xbot/plugins/rain/users.py")

        msg = f"Airdropped {amount_single} {con.T2X_TICKER} each to following users:\n"
        suffix = ", "

        delay = self.config.get("delay")

        try:
            # Read generated CSV file
            with open(os.path.join(self.get_res_path(), "users.csv"), newline="\n") as f:
                users = csv.reader(f, delimiter=",")

                index = 0
                issue = 0
                for user in users:
                    if index >= nr_of_users:
                        break
                    else:
                        index += 1

                        to_username = user[0]
                        to_user_id = user[1]
                        to_address, _ = self.add_user_wallet(user[1], return_data=True)

                    try:
                        # Tip user
                        tip = T2X().send(tron, to_address, amount_single)

                        logging.info(f"Tipped {amount_single} {con.T2X_TICKER} from "
                                     f"{res['data'][0][1]} to {to_address} - "
                                     f"{to_username} ({to_user_id}): {tip}")

                        if "transaction" not in tip:
                            raise Exception(f"Key 'transaction' not in result: {tip}")

                        txid = tip["transaction"]["txID"]

                        msg += to_username + suffix

                        # Insert details into database
                        sql = self.get_resource("insert_rain.sql")
                        self.execute_sql(sql, from_user_id, to_user_id, T2X.to_atom(amount_single), txid)
                    except Exception as e:
                        error_msg = f"{emo.ERROR} Can not rain on {to_username} ({to_user_id}): {e}"
                        logging.error(error_msg)
                        issue += 1

                    # Delay sending out transaction to not spam the node
                    time.sleep(delay)

                if issue > 0:
                    logging.error(f"{emo.ERROR} Could not rain on {issue} user(s)")

        except Exception as e:
            msg = f"{emo.ERROR} Not possible to rain: {e}"
            logging.error(f"{msg} - {update}")
            update.message.reply_text(msg)

        # Make sure that the message text will only be changed if some rain happened
        if msg.endswith(suffix):
            msg = msg[:-len(suffix)]
            message.edit_text(msg)
