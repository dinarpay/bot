import logging
import t2xbot.emoji as emo

from tronapi import Tron
from telegram import ParseMode
from trx_utils import is_address
from t2xbot.tronscan import Tronscan
from t2xbot.plugin import T2XBotPlugin


class Withdrawtrx(T2XBotPlugin):

    def __enter__(self):
        if not self.table_exists("withdrawals"):
            sql = self.get_resource("create_withdrawals.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.private
    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        if len(args) != 1:
            update.message.reply_text(
                text=f"Usage:\n{self.get_usage()}",
                parse_mode=ParseMode.MARKDOWN)
            return

        to_address = args[0]

        # Check if provided address is valid
        if not bool(is_address(to_address)):
            msg = f"{emo.ERROR} Provided TRX wallet is not valid"
            update.message.reply_text(msg)
            return

        user_id = update.effective_user.id

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, user_id)

        if not res["success"] or not res["data"]:
            msg = f"{emo.ERROR} Something went wrong. Please contact @endogen"

            logging.error(f"{msg}: {res} - {update}")
            update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)
            return

        from_address = res["data"][0][1]

        trx_kwargs = dict()
        trx_kwargs["private_key"] = res["data"][0][2]
        trx_kwargs["default_address"] = from_address

        tron = Tron(**trx_kwargs)

        balance_atom = tron.trx.get_balance()
        balance_show = float(tron.fromSun(balance_atom))

        try:
            send = tron.trx.send(to_address, balance_show)
            logging.info(f"Withdrawn {balance_show} TRX from {from_address} to {to_address}: {send}")

            if "transaction" not in send:
                logging.error(f"Key 'transaction' not in result")
                raise Exception(send["message"])

            txid = send["transaction"]["txID"]

            sql = self.get_resource("insert_withdrawal.sql")
            self.execute_sql(sql, from_address, to_address, balance_atom, txid)

            if balance_show.is_integer():
                balance_show = int(balance_show)

            message = update.message.reply_text(
                f"{emo.DONE} Withdrawn `{balance_show}` TRX\n"
                f"[View on Explorer]({Tronscan.TX_URL}{txid})",
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True)

            self.remove_msg(message, also_private=False)
        except Exception as e:
            msg = f"{emo.ERROR} Could not withdraw TRX: {e}"

            logging.error(msg)
            update.message.reply_text(msg)
