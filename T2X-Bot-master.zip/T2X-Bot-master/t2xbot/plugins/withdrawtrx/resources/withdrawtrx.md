
`/{{handle}} <address>`
Use this command to withdraw the *whole amount* of TRX in your wallet and sent it over to another wallet