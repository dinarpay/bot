from t2xbot.plugin import T2XBotPlugin


class _init(T2XBotPlugin):

    def __enter__(self):
        if not self.global_table_exists("users"):
            sql = self.get_global_resource("create_users.sql")
            self.execute_global_sql(sql)
        return self
