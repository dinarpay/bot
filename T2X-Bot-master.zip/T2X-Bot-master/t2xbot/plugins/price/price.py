import time
import logging
import t2xbot.emoji as emo
import t2xbot.utils as utl

from telegram import ParseMode
from datetime import datetime, timedelta
from t2xbot.plugin import T2XBotPlugin
from t2xbot.t2x import T2X


class Price(T2XBotPlugin):

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        message = update.message.reply_text(f"{emo.WAIT} Checking price...")

        msg = f"T2X Price"
        message.edit_text(msg, parse_mode=ParseMode.MARKDOWN)
