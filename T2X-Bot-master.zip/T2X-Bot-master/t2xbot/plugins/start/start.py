from telegram import ParseMode
from t2xbot.plugin import T2XBotPlugin


class Start(T2XBotPlugin):

    ABOUT_FILE = "about.md"

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    def execute(self, bot, update, args):
        user = update.effective_user

        sql = self.get_global_resource("select_user.sql")
        res = self.execute_global_sql(sql, user.id)

        address = res["data"][0][1]

        about = self.get_resource(self.ABOUT_FILE)
        about = about.replace("{{address}}", address)

        update.message.reply_text(
            about,
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True)
