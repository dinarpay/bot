✨ *T2X - Next Generation Staking* ✨

Welcome to T2X! Visit the [website](http://t2xtoken.io) to learn more about T2X. This bot will give you the possibility to deposit and send T2X tokens and to tip users.  

Your generated T2X wallet address:
`{{address}}`

Cheers 🍻👋