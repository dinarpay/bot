import time
import logging
import t2xbot.emoji as emo
import t2xbot.utils as utl

from telegram import ParseMode
from datetime import datetime, timedelta
from t2xbot.plugin import T2XBotPlugin
from t2xbot.t2x import T2X
from t2xbot.trongrid import Trongrid


class Dividends(T2XBotPlugin):

    DECIMALS = 6
    MAX_DATA = 200

    def __enter__(self):
        if not self.table_exists("dividends"):
            sql = self.get_resource("create_divs.sql")
            self.execute_sql(sql)
        return self

    @T2XBotPlugin.add_user
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        message = update.message.reply_text(f"{emo.WAIT} Calculating Auction Pool Size...")

        tx_kwargs = dict()
        tx_kwargs["limit"] = self.MAX_DATA

        now = datetime.utcnow()
        start = now - timedelta(hours=now.hour, minutes=now.minute, seconds=now.second)

        # Get last inserted transaction
        res = self.execute_sql(self.get_resource("select_last.sql"))

        # If there is data in the database
        if res and res["data"]:
            # Create datetime from milliseconds of last tx
            last = datetime.utcfromtimestamp(res["data"][0][0] // 1000)
            # If day of last inserted tx == current day
            if last.day == now.day:
                # Take timestamp of last inserted tx
                min_timestamp = str(int(res["data"][0][0]))
            else:
                # Remove old data from table
                self.execute_sql(self.get_resource("delete_divs.sql"))
                min_timestamp = utl.to_unix_time(start, millis=True)
        else:
            min_timestamp = utl.to_unix_time(start, millis=True)

        tx_kwargs["min_timestamp"] = min_timestamp

        delay = self.config.get("delay")

        while True:
            # Get all transactions to or from contract
            transactions = Trongrid().get_transactions(T2X.T2X_SC, **tx_kwargs)

            for tx in transactions["data"]:
                if "raw_data" not in tx:
                    logging.info(f"No 'raw_data': {tx}")
                    continue

                if tx["ret"][0]["contractRet"] != "SUCCESS":
                    logging.info(f"No 'SUCCESS': {tx}")
                    continue

                details = tx["raw_data"]["contract"][0]["parameter"]["value"]

                if "call_value" not in details:
                    logging.info(f"No 'call_value': {tx}")
                    continue

                if details["call_value"] > 0:
                    sql = self.get_resource("select_exists.sql")
                    res = self.execute_sql(sql, tx["txID"])

                    if res["data"][0][0] == 0:
                        timestamp = tx['raw_data']['timestamp']
                        amount = details["call_value"]
                        txid = tx["txID"]

                        # Save tx details in database
                        sql = self.get_resource("insert_divs.sql")
                        self.execute_sql(sql, timestamp, amount, txid)

                        amount_trx = int(amount / 10 ** self.DECIMALS)
                        logging.info(f"Added to Auction: {timestamp} - {txid} - {amount_trx} TRX")
                else:
                    logging.info(f"No positive 'call_value': {tx}")

            # End loop if we got less than requested max number of transactions
            if not len(transactions["data"]) == self.MAX_DATA:
                break

            # Set fingerprint of last request to continue the next one
            tx_kwargs["fingerprint"] = transactions["meta"]["fingerprint"]
            time.sleep(delay)

        # Sum up all the sent TRX
        sql = self.get_resource("select_divs.sql")
        res = self.execute_sql(sql)

        final_sum = 0
        for tx_data in res["data"]:
            final_sum += tx_data[1]

        msg = f"`Auction Pool: {format(int(final_sum / 10 ** self.DECIMALS), ',d')} TRX`"
        message.edit_text(msg, parse_mode=ParseMode.MARKDOWN)
