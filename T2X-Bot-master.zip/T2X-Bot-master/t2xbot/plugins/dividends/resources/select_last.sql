SELECT *
FROM dividends
ORDER BY date_time DESC LIMIT 1