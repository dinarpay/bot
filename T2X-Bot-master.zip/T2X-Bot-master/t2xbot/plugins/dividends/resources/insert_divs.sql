INSERT INTO dividends (time_stamp, amount, txid)
VALUES (?, ?, ?)