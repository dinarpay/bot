SELECT *
FROM dividends