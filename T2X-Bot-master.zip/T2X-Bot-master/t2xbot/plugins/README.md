# T2X-Bot Plugins
This is a list of available plugins for this bot