import os
import logging
import t2xbot.emoji as emo
import t2xbot.constants as con

from t2xbot.plugin import T2XBotPlugin


class Logfile(T2XBotPlugin):

    @T2XBotPlugin.owner
    @T2XBotPlugin.private
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        base_dir = os.path.abspath(os.getcwd())
        log_file = os.path.join(base_dir, con.DIR_LOG, con.FILE_LOG)

        if os.path.isfile(log_file):
            try:
                file = open(log_file, 'rb')
            except Exception as e:
                logging.error(e)
                self.notify(e)
                file = None
        else:
            file = None

        if file:
            update.message.reply_document(
                caption=f"{emo.DONE} Current Logfile",
                document=file)
        else:
            update.message.reply_text(
                text=f"{emo.ERROR} Not possible to download logfile")
