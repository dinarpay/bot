import threading
import t2xbot.emoji as emo

from t2xbot.plugin import T2XBotPlugin


class Shutdown(T2XBotPlugin):

    @T2XBotPlugin.owner
    @T2XBotPlugin.private
    @T2XBotPlugin.threaded
    @T2XBotPlugin.send_typing
    def execute(self, bot, update, args):
        msg = f"{emo.GOODBYE} Shutting down..."
        update.message.reply_text(msg)

        threading.Thread(target=self._shutdown_thread).start()

    # TODO: Remove access to protected variable
    def _shutdown_thread(self):
        self._tgb.updater.stop()
        self._tgb.updater.is_idle = False
