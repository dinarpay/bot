#!/bin/bash

python3 -m t2xbot -log 20